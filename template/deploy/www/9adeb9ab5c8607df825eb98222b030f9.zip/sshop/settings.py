import os

limit = 10
username = '4uuu'
email = 'i@qvq.im'
debug = True

connect_str = 'sqlite:///%s' % os.path.join(os.getcwd(), 'sshop.db3')
cookie_secret = '5f55e8c1487401007e1b56211abd85de5fe57f9fc0079e5060e981f025d2'
